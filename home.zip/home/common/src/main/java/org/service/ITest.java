package org.service;

import org.model.User;

/**
 * @ClassName: ITest
 * @Description:
 * @author: like
 * @date 2022/3/31 13:59
 */
public interface ITest {
    public User getUser();
}
